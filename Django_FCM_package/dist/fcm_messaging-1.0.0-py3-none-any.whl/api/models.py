from django.core.exceptions import ValidationError
from django.db import models


class FCMCertificate(models.Model):
    name = models.CharField(
        max_length=255,
        unique=True,
        help_text="A unique name for this Firebase project/certificate.",
    )
    certificate_json = models.FileField(upload_to="certificates/")

    def clean(self):
        if self.name and FCMCertificate.objects.filter(name=self.name).exists() and not self.pk:
            raise ValidationError("Only one certificate can exist with this name.")

    def save(self, *args, **kwargs):
        self.full_clean()  # calls clean()
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name
